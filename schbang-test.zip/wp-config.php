<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'schbang-test' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '&uq/NpU=a#GkAB0d$8W]XqV>d8Q)`|Ll2(3Ei#{+.e  E9#.]Ez;7~iakx#]P79l' );
define( 'SECURE_AUTH_KEY',  'y6fOi`01gJJ5A]hiD_fS9Q;m80&Gq->9?S.#o7V:=k9Nn[YhnPG@izj5>DMj^#`0' );
define( 'LOGGED_IN_KEY',    'AhS&EA%uv,^_q<8C!#ed3-jmNVbeQSY%Yv}m;`k.N@Qj<z0uk.i|Ny!dapf}Kh|)' );
define( 'NONCE_KEY',        '_|9S/E&<mQE|cU 7af[l_CvaP9#~al*POnj<-+-wNA_Tu%(x4/qfIU_5[^Ze3awm' );
define( 'AUTH_SALT',        'TjNDqufB#Pc5J:J60OuCZ!Rzl7t%~OpBb]9]sQEg<dCD5V3ldiMVcPx#1]<J7TO?' );
define( 'SECURE_AUTH_SALT', 'trb=jP-v^-c@P5I6P~z|e]D)$wA#[:[i=+86_m@O[Ebs^!l#[qo1MG5a,<^d&_}f' );
define( 'LOGGED_IN_SALT',   '-gy`6d{eA>2[V!19K]0FLb@$@$s4z0OEW%*SH?;G`o<E6:/PR5<w2b/E,sk|P*(_' );
define( 'NONCE_SALT',       '2c8S42,K-,,h!F%Ra@(E?achKv.:FDJyaf#l6 bu%DRa1.G=yyFZ|!@TE;(VFeS?' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
